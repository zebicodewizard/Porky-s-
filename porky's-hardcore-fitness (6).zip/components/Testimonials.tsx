
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

const Testimonials: React.FC = () => {
  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="flex flex-col items-center text-center mb-16">
        <div className="flex gap-1 mb-4">
          {[...Array(5)].map((_, i) => (
            <Star key={i} size={20} fill="#a3e635" className="text-lime-400" />
          ))}
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
          What the <span className="text-lime-400">Hustlers</span> Say
        </h2>
        <p className="text-zinc-400">4.9/5 Average rating based on 180+ Google reviews.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {TESTIMONIALS.map((testimonial) => (
          <div
            key={testimonial.id}
            className="bg-zinc-950/40 p-10 rounded-3xl border border-zinc-800/50 relative overflow-hidden group hover:border-lime-400/20 transition-all"
          >
            <Quote className="absolute -top-4 -right-4 w-24 h-24 text-lime-400/5 group-hover:text-lime-400/10 transition-colors" />
            
            <p className="text-lg text-zinc-300 italic mb-8 leading-relaxed relative z-10">
              "{testimonial.text}"
            </p>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-lime-400/20 flex items-center justify-center font-bold text-lime-400">
                {testimonial.author[0]}
              </div>
              <div>
                <h4 className="font-bold uppercase tracking-wider text-sm">
                  {testimonial.author}
                </h4>
                <div className="flex gap-0.5">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={10} fill="#a3e635" className="text-lime-400" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;

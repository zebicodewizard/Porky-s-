
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Bot, Send, X, MessageSquare, Loader2, Apple } from 'lucide-react';

const AINutritionAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: "Hey! I'm your AI Nutrition Coach at Porky's. Want some advice on supplements or a quick meal plan to hit your goals?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: `You are a hardcore nutrition and fitness coach at "Porky's Hardcore Fitness". 
          Your tone is energetic, motivating, professional, and results-oriented. 
          Keep answers concise (under 100 words). 
          Mention that Porky's has an in-house nutrition store for supplements if relevant.
          Focus on bodybuilding, strength gains, and fat loss.`
        }
      });

      const aiResponse = response.text || "Sorry, I lost my focus for a second. Let's try again.";
      setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
    } catch (error) {
      console.error('Gemini API Error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Something went wrong. Make sure you're connected to the net and try again!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`bg-lime-400 text-zinc-950 p-4 rounded-full shadow-[0_10px_40px_rgba(163,230,53,0.4)] hover:scale-110 active:scale-95 transition-all flex items-center gap-2 group ${isOpen ? 'rotate-90' : ''}`}
      >
        {isOpen ? <X size={24} /> : (
          <>
            <Bot size={24} />
            <span className="hidden md:block font-bold uppercase tracking-widest text-xs">Nutrition AI</span>
          </>
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="absolute bottom-20 right-0 w-[350px] md:w-[400px] h-[500px] bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 duration-300">
          {/* Header */}
          <div className="bg-zinc-800 p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-lime-400 p-2 rounded-xl text-zinc-950">
                <Apple size={20} />
              </div>
              <div>
                <h3 className="font-bold uppercase tracking-tight text-white leading-none">Porky's AI Coach</h3>
                <span className="text-[10px] text-lime-400 uppercase font-black tracking-widest">Always Active</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-zinc-500 hover:text-white transition-colors">
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-grow overflow-y-auto p-5 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-lime-400 text-zinc-950 font-bold rounded-tr-none'
                      : 'bg-zinc-800 text-zinc-300 rounded-tl-none border border-zinc-700'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start italic text-zinc-500 text-xs items-center gap-2">
                <Loader2 size={14} className="animate-spin" /> Coach is thinking...
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-4 bg-zinc-950 border-t border-zinc-800">
            <div className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about protein, cuts, or gains..."
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-4 pr-12 py-3 focus:outline-none focus:border-lime-400 transition-colors text-sm"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-lime-400 text-zinc-950 p-2 rounded-lg hover:bg-lime-300 disabled:opacity-50 transition-all"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AINutritionAssistant;

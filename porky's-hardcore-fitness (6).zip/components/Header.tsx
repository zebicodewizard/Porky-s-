import React, { useState, useEffect } from 'react';
import { Menu, X, Dumbbell, User as UserIcon, LogOut, LayoutDashboard } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { User } from '@supabase/supabase-js';

interface HeaderProps {
  user: User | null;
  onAuthClick: () => void;
  onProfileClick: () => void;
  onHomeClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onAuthClick, onProfileClick, onHomeClick }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const navLinks = [
    { name: 'Home', href: '#home', onClick: onHomeClick },
    { name: 'Programs', href: '#programs', onClick: onHomeClick },
    { name: 'Trainers', href: '#trainers', onClick: onHomeClick },
    { name: 'Pricing', href: '#pricing', onClick: onHomeClick },
    { name: 'Schedule', href: '#schedule', onClick: onHomeClick },
    { name: 'Contact', href: '#contact', onClick: onHomeClick },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-zinc-950/95 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <button onClick={onHomeClick} className="flex items-center gap-2 group">
          <Dumbbell className="w-8 h-8 text-lime-400 group-hover:rotate-12 transition-transform" />
          <span className="font-display text-2xl font-bold tracking-tighter uppercase italic">
            Porky's <span className="text-lime-400">Hardcore</span>
          </span>
        </button>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={link.onClick}
              className="text-sm font-semibold uppercase tracking-widest hover:text-lime-400 transition-colors"
            >
              {link.name}
            </a>
          ))}
          
          {user ? (
            <div className="flex items-center gap-4">
              <button
                onClick={onProfileClick}
                className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-full hover:border-lime-400/50 transition-all"
              >
                <UserIcon size={16} className="text-lime-400" />
                <span className="text-xs font-bold truncate max-w-[100px]">{user.email?.split('@')[0]}</span>
              </button>
              <button
                onClick={handleLogout}
                className="text-zinc-500 hover:text-red-400 transition-colors"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <button
              onClick={onAuthClick}
              className="bg-lime-400 text-black px-6 py-2.5 rounded-full font-bold uppercase tracking-wider text-sm hover:bg-lime-300 transition-colors"
            >
              Join Now
            </button>
          )}
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-zinc-100"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isMenuOpen && (
        <div className="md:hidden bg-zinc-950 border-t border-zinc-800 absolute top-full left-0 w-full animate-in slide-in-from-top duration-300 shadow-2xl">
          <nav className="flex flex-col p-6 gap-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-lg font-bold uppercase tracking-widest hover:text-lime-400"
                onClick={() => { link.onClick(); setIsMenuOpen(false); }}
              >
                {link.name}
              </a>
            ))}
            {user ? (
              <>
                <button
                  onClick={() => { onProfileClick(); setIsMenuOpen(false); }}
                  className="flex items-center justify-center gap-2 bg-zinc-800 text-white py-4 rounded-lg font-bold uppercase"
                >
                  <LayoutDashboard size={18} /> My Profile
                </button>
                <button
                  onClick={() => { handleLogout(); setIsMenuOpen(false); }}
                  className="bg-red-500 text-white text-center py-4 rounded-lg font-bold uppercase"
                >
                  Logout
                </button>
              </>
            ) : (
              <button
                onClick={() => { onAuthClick(); setIsMenuOpen(false); }}
                className="bg-lime-400 text-black text-center py-4 rounded-lg font-bold uppercase"
              >
                Join Now
              </button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
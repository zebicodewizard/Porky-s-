import React, { useState, useEffect } from 'react';
import { MapPin, Phone, Clock, Send, Loader2, CheckCircle } from 'lucide-react';
import { GYM_DETAILS } from '../constants';
import { supabase } from '../supabaseClient';
import { User } from '@supabase/supabase-js';

interface ContactProps {
  user?: User | null;
}

const Contact: React.FC<ContactProps> = ({ user }) => {
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    goal: 'Bodybuilding',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (user?.email) {
      setFormData(prev => ({ ...prev, email: user.email }));
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.full_name || !formData.email) return;

    setStatus('submitting');
    try {
      const { error } = await supabase
        .from('contacts')
        .insert([
          { 
            full_name: formData.full_name, 
            email: formData.email, 
            goal: formData.goal, 
            message: formData.message,
            user_id: user?.id, // Link to auth user if exists
            created_at: new Date().toISOString()
          }
        ]);

      if (error) throw error;
      setStatus('success');
      setFormData(prev => ({ ...prev, full_name: '', message: '' }));
      setTimeout(() => setStatus('idle'), 5000);
    } catch (err) {
      console.error('Error submitting to Supabase:', err);
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Info Column */}
        <div>
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-8 italic">
            Get in <span className="text-lime-400">Touch</span>
          </h2>
          <p className="text-zinc-400 mb-12 max-w-lg leading-relaxed">
            Ready to change your life? Visit us at Porky's or drop a message. Our community is waiting to welcome you to the hardcore side of Miami fitness.
          </p>

          <div className="space-y-8">
            <div className="flex items-start gap-5">
              <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 text-lime-400">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Our Location</h4>
                <p className="text-zinc-400 text-sm">{GYM_DETAILS.address}</p>
              </div>
            </div>

            <div className="flex items-start gap-5">
              <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 text-lime-400">
                <Phone size={24} />
              </div>
              <div>
                <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Call Us</h4>
                <p className="text-zinc-400 text-sm">{GYM_DETAILS.phone}</p>
              </div>
            </div>

            <div className="flex items-start gap-5">
              <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 text-lime-400">
                <Clock size={24} />
              </div>
              <div>
                <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Business Hours</h4>
                <p className="text-zinc-400 text-sm">{GYM_DETAILS.hours}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Column */}
        <div className="bg-zinc-900 p-8 md:p-12 rounded-[2.5rem] border border-zinc-800 shadow-2xl relative">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Full Name</label>
                <input
                  type="text"
                  name="full_name"
                  value={formData.full_name}
                  onChange={handleChange}
                  required
                  placeholder="John Doe"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-5 py-4 focus:outline-none focus:border-lime-400 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Email Address</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="john@example.com"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-5 py-4 focus:outline-none focus:border-lime-400 transition-colors disabled:opacity-50"
                  disabled={!!user}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Goal</label>
              <select 
                name="goal"
                value={formData.goal}
                onChange={handleChange}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-5 py-4 focus:outline-none focus:border-lime-400 appearance-none transition-colors"
              >
                <option>Bodybuilding</option>
                <option>Weight Loss</option>
                <option>Competition Prep</option>
                <option>General Fitness</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Message</label>
              <textarea
                rows={4}
                name="message"
                value={formData.message}
                onChange={handleChange}
                placeholder="How can we help you crush your goals?"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-5 py-4 focus:outline-none focus:border-lime-400 transition-colors"
              ></textarea>
            </div>

            <button 
              type="submit"
              disabled={status === 'submitting'}
              className={`group w-full py-5 rounded-xl font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 active:scale-95 shadow-[0_10px_30px_rgba(163,230,53,0.3)] ${
                status === 'submitting' 
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                : 'bg-lime-400 text-zinc-950 hover:bg-lime-300'
              }`}
            >
              {status === 'submitting' ? (
                <>Sending... <Loader2 size={20} className="animate-spin" /></>
              ) : (
                <>Send Message <Send size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /></>
              )}
            </button>

            {status === 'success' && (
              <div className="flex items-center gap-2 text-lime-400 font-bold justify-center animate-in fade-in slide-in-from-top-2">
                <CheckCircle size={20} /> Message Sent! We'll reach out soon.
              </div>
            )}
            
            {status === 'error' && (
              <div className="text-red-400 font-bold text-center text-sm bg-red-400/10 p-4 rounded-xl">
                Error sending message. Check your connection or try again.
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
import React, { useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../supabaseClient';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

interface ScheduleProps {
  user: User | null;
  onAuthRequired: () => void;
}

const Schedule: React.FC<ScheduleProps> = ({ user, onAuthRequired }) => {
  const [activeDay, setActiveDay] = useState('Mon');
  const [bookingStatus, setBookingStatus] = useState<{ [key: string]: 'idle' | 'loading' | 'success' | 'error' }>({});

  const classes = {
    'Mon': [
      { id: 'm1', time: '06:00 AM', name: 'Hardcore Cardio', instructor: 'Marco Silva' },
      { id: 'm2', time: '09:00 AM', name: 'Bodybuilding 101', instructor: 'David Chen' },
      { id: 'm3', time: '05:00 PM', name: 'Power Hour', instructor: 'Marco Silva' },
      { id: 'm4', time: '07:30 PM', name: 'Supplements Q&A', instructor: 'Sarah Jenkins' },
    ],
    'Tue': [
      { id: 't1', time: '07:00 AM', name: 'Strength Foundations', instructor: 'David Chen' },
      { id: 't2', time: '10:00 AM', name: 'Nutrition Focus', instructor: 'Sarah Jenkins' },
      { id: 't3', time: '06:00 PM', name: 'Leg Day Massacre', instructor: 'Marco Silva' },
    ],
    'Wed': [
      { id: 'w1', time: '06:00 AM', name: 'Functional Power', instructor: 'David Chen' },
      { id: 'w2', time: '05:00 PM', name: 'Chest & Tris', instructor: 'Marco Silva' },
    ],
    'Thu': [
      { id: 'th1', time: '08:00 AM', name: 'Abs & Core', instructor: 'Sarah Jenkins' },
      { id: 'th2', time: '06:00 PM', name: 'Back Attack', instructor: 'Marco Silva' },
    ],
    'Fri': [
      { id: 'f1', time: '06:00 AM', name: 'Cardio Blast', instructor: 'David Chen' },
      { id: 'f2', time: '04:00 PM', name: 'Arms Blitz', instructor: 'Marco Silva' },
    ],
    'Sat': [
      { id: 's1', time: '09:00 AM', name: 'Open Training', instructor: 'All Staff' },
      { id: 's2', time: '11:00 AM', name: 'Form Correction', instructor: 'David Chen' },
    ],
    'Sun': [
      { id: 'su1', time: '10:00 AM', name: 'Recovery Session', instructor: 'Sarah Jenkins' },
    ],
  };

  const handleBookSpot = async (classItem: any) => {
    if (!user) {
      onAuthRequired();
      return;
    }

    const bookingId = `${activeDay}-${classItem.id}`;
    setBookingStatus(prev => ({ ...prev, [bookingId]: 'loading' }));

    try {
      const { error } = await supabase
        .from('bookings')
        .insert([
          {
            user_id: user.id,
            class_name: classItem.name,
            class_time: classItem.time,
            instructor: classItem.instructor,
            booking_day: activeDay
          }
        ]);

      if (error) throw error;
      setBookingStatus(prev => ({ ...prev, [bookingId]: 'success' }));
      setTimeout(() => setBookingStatus(prev => ({ ...prev, [bookingId]: 'idle' })), 3000);
    } catch (err) {
      console.error('Booking error:', err);
      setBookingStatus(prev => ({ ...prev, [bookingId]: 'error' }));
      setTimeout(() => setBookingStatus(prev => ({ ...prev, [bookingId]: 'idle' })), 3000);
    }
  };

  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="text-center mb-16">
        <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
          Weekly <span className="text-lime-400">Regiment</span>
        </h2>
        <p className="text-zinc-400">Find your session and commit. Log in to reserve your spot.</p>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mb-10">
        {DAYS.map((day) => (
          <button
            key={day}
            onClick={() => setActiveDay(day)}
            className={`px-6 py-3 rounded-full font-bold uppercase tracking-widest text-sm transition-all ${activeDay === day ? 'bg-lime-400 text-zinc-950' : 'bg-zinc-900 text-zinc-500 hover:text-white hover:bg-zinc-800'}`}
          >
            {day}
          </button>
        ))}
      </div>

      <div className="max-w-4xl mx-auto space-y-4">
        {classes[activeDay as keyof typeof classes].map((item) => {
          const status = bookingStatus[`${activeDay}-${item.id}`] || 'idle';
          return (
            <div
              key={item.id}
              className="group flex flex-col md:flex-row items-center justify-between p-6 bg-zinc-900/50 border border-zinc-800/50 rounded-2xl hover:bg-zinc-900 hover:border-lime-400/30 transition-all duration-300"
            >
              <div className="flex items-center gap-6 mb-4 md:mb-0">
                <span className="text-xl font-display font-bold italic text-lime-400 min-w-[120px]">
                  {item.time}
                </span>
                <div>
                  <h4 className="text-lg font-bold uppercase tracking-wide group-hover:text-lime-400 transition-colors">
                    {item.name}
                  </h4>
                  <p className="text-xs text-zinc-500 uppercase tracking-widest font-semibold">
                    With {item.instructor}
                  </p>
                </div>
              </div>
              
              <button 
                onClick={() => handleBookSpot(item)}
                disabled={status !== 'idle'}
                className={`min-w-[140px] px-6 py-3 rounded-lg font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                  status === 'success' ? 'bg-lime-400/20 text-lime-400' :
                  status === 'error' ? 'bg-red-500/20 text-red-500' :
                  'bg-zinc-800 text-white hover:bg-lime-400 hover:text-zinc-950'
                }`}
              >
                {status === 'loading' && <Loader2 size={14} className="animate-spin" />}
                {status === 'success' && <CheckCircle size={14} />}
                {status === 'error' && <AlertCircle size={14} />}
                
                {status === 'idle' && 'Book Spot'}
                {status === 'loading' && 'Booking...'}
                {status === 'success' && 'Confirmed'}
                {status === 'error' && 'Failed'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Schedule;
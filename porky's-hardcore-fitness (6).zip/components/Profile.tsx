import React, { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../supabaseClient';
import { Calendar, MessageSquare, Trash2, Clock, MapPin, User as UserIcon, Loader2 } from 'lucide-react';

interface ProfileProps {
  user: User | null;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const [bookings, setBookings] = useState<any[]>([]);
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  const fetchUserData = async () => {
    setLoading(true);
    try {
      const [bookingsRes, inquiriesRes] = await Promise.all([
        supabase.from('bookings').select('*').order('created_at', { ascending: false }),
        supabase.from('contacts').select('*').order('created_at', { ascending: false })
      ]);

      if (bookingsRes.data) setBookings(bookingsRes.data);
      if (inquiriesRes.data) setInquiries(inquiriesRes.data);
    } catch (err) {
      console.error('Error fetching profile data:', err);
    } finally {
      setLoading(false);
    }
  };

  const cancelBooking = async (id: string) => {
    const { error } = await supabase.from('bookings').delete().eq('id', id);
    if (!error) {
      setBookings(prev => prev.filter(b => b.id !== id));
    }
  };

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="max-w-6xl mx-auto">
        {/* Profile Header */}
        <div className="bg-zinc-900 rounded-[2.5rem] p-8 md:p-12 mb-12 border border-zinc-800 flex flex-col md:flex-row items-center gap-8">
          <div className="w-24 h-24 rounded-full bg-lime-400 flex items-center justify-center text-zinc-950">
            <UserIcon size={48} />
          </div>
          <div className="text-center md:text-left">
            <h1 className="font-display text-4xl md:text-5xl font-bold uppercase italic tracking-tighter mb-2">
              User <span className="text-lime-400">Profile</span>
            </h1>
            <p className="text-zinc-500 font-bold uppercase tracking-widest text-sm">{user.email}</p>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 size={40} className="text-lime-400 animate-spin" />
            <p className="text-zinc-500 font-bold uppercase tracking-widest">Loading your data...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* My Bookings */}
            <div>
              <div className="flex items-center gap-3 mb-8">
                <Calendar className="text-lime-400" size={28} />
                <h2 className="font-display text-3xl font-bold uppercase italic tracking-tight">Active <span className="text-lime-400">Bookings</span></h2>
              </div>

              <div className="space-y-4">
                {bookings.length === 0 ? (
                  <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-2xl p-8 text-center">
                    <p className="text-zinc-500 text-sm uppercase font-bold tracking-widest">No active bookings found.</p>
                  </div>
                ) : (
                  bookings.map((booking) => (
                    <div key={booking.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex items-center justify-between group">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lime-400 font-black text-xs uppercase tracking-widest">{booking.booking_day}</span>
                          <span className="text-zinc-500">•</span>
                          <span className="text-zinc-400 text-xs font-bold uppercase tracking-widest">{booking.class_time}</span>
                        </div>
                        <h3 className="text-xl font-bold uppercase tracking-tight text-white">{booking.class_name}</h3>
                        <p className="text-zinc-500 text-xs uppercase font-bold tracking-widest mt-1">Coach: {booking.instructor}</p>
                      </div>
                      <button 
                        onClick={() => cancelBooking(booking.id)}
                        className="p-3 text-zinc-600 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-all"
                        title="Cancel Booking"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* My Inquiries */}
            <div>
              <div className="flex items-center gap-3 mb-8">
                <MessageSquare className="text-lime-400" size={28} />
                <h2 className="font-display text-3xl font-bold uppercase italic tracking-tight">Message <span className="text-lime-400">History</span></h2>
              </div>

              <div className="space-y-4">
                {inquiries.length === 0 ? (
                  <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-2xl p-8 text-center">
                    <p className="text-zinc-500 text-sm uppercase font-bold tracking-widest">No inquiry history found.</p>
                  </div>
                ) : (
                  inquiries.map((inquiry) => (
                    <div key={inquiry.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
                      <div className="flex justify-between items-start mb-4">
                        <span className="bg-lime-400/10 text-lime-400 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                          Goal: {inquiry.goal}
                        </span>
                        <span className="text-zinc-600 text-[10px] font-bold uppercase tracking-widest">
                          {new Date(inquiry.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-zinc-300 text-sm italic mb-4 leading-relaxed">
                        "{inquiry.message || "No message provided."}"
                      </p>
                      <div className="flex items-center gap-2 text-zinc-500 text-xs font-bold uppercase tracking-widest">
                        <Clock size={12} />
                        Waiting for response
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
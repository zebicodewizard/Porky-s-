import React from 'react';

const Gallery: React.FC = () => {
  const images = [
    'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=1470', // Facility 1
    'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&q=80&w=1470', // Facility 2
    'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1470', // Facility 3
    'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?auto=format&fit=crop&q=80&w=1375', // Facility 4
    'https://onedegree.com.pk/cdn/shop/articles/shop_best_Gym_Accessories_online_in_pakistan.jpg?v=1758797754&width=1600', // Facility 5 (Updated)
    'https://trainingstation.co.uk/cdn/shop/articles/6189201ee71c047d436bdc97_IMGC9877-min-p-1080_1080x.jpg?v=1709544497', // Facility 6
  ];

  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="text-center mb-16">
        <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
          The <span className="text-lime-400">Battleground</span>
        </h2>
        <p className="text-zinc-400 max-w-2xl mx-auto">
          Take a look inside Miami's most hardcore training facility. No fancy lights, no distractions—just iron and sweat.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((src, idx) => (
          <div 
            key={idx} 
            className="group relative aspect-square overflow-hidden rounded-2xl bg-zinc-900 border border-zinc-800"
          >
            <img
              src={src}
              alt={`Gym Facility ${idx + 1}`}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-zinc-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-lime-400 font-display text-xl font-bold uppercase italic tracking-widest">
                Zone {idx + 1}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
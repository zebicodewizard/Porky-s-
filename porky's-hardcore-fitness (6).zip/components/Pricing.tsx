
import React from 'react';
import { Check, Info } from 'lucide-react';
import { PRICING } from '../constants';

const Pricing: React.FC = () => {
  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="text-center mb-16">
        <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
          Choose Your <span className="text-lime-400">Battle Plan</span>
        </h2>
        <p className="text-zinc-400 max-w-xl mx-auto">
          No hidden fees. No corporate BS. Just straightforward pricing for serious training.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {PRICING.map((plan) => (
          <div
            key={plan.id}
            className={`relative flex flex-col p-8 rounded-3xl transition-all duration-300 ${plan.isFeatured ? 'bg-zinc-100 text-zinc-950 scale-105 shadow-[0_0_40px_rgba(163,230,53,0.3)] z-10' : 'bg-zinc-900 border border-zinc-800'}`}
          >
            {plan.isFeatured && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-lime-400 text-zinc-950 px-4 py-1 rounded-full text-xs font-black uppercase italic shadow-lg">
                Most Popular
              </div>
            )}
            
            <div className="mb-8">
              <h3 className="text-lg font-bold uppercase tracking-widest mb-2 opacity-70">
                {plan.name}
              </h3>
              <div className="flex items-baseline gap-1">
                <span className="text-5xl font-display font-bold italic">{plan.price}</span>
                <span className="text-sm font-semibold opacity-60">/month</span>
              </div>
            </div>

            <ul className="flex-grow space-y-4 mb-10">
              {plan.features.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm font-medium">
                  <div className={`mt-0.5 rounded-full p-0.5 ${plan.isFeatured ? 'bg-lime-400 text-zinc-950' : 'bg-zinc-800 text-lime-400'}`}>
                    <Check size={14} />
                  </div>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            <button
              className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest transition-all ${plan.isFeatured ? 'bg-zinc-950 text-lime-400 hover:bg-zinc-800' : 'bg-lime-400 text-zinc-950 hover:bg-lime-300'}`}
            >
              Get Started
            </button>
            
            <p className="mt-4 text-[10px] text-center uppercase tracking-tighter opacity-50 flex items-center justify-center gap-1">
              <Info size={10} /> Cancellation requires 30-day notice
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;

import React from 'react';
import { Instagram, Twitter, Facebook } from 'lucide-react';
import { TRAINERS } from '../constants';

const Trainers: React.FC = () => {
  const socialLink = "https://www.instagram.com/porkys_kendall?igsh=dWxkZ3pzMTVubmc4";

  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="flex flex-col md:flex-row items-end justify-between gap-6 mb-16">
        <div className="max-w-xl">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
            Meet the <span className="text-lime-400">Warriors</span>
          </h2>
          <p className="text-zinc-400">
            Our trainers aren't just staff—they are lifelong athletes dedicated to helping you reach your peak physical potential.
          </p>
        </div>
        <a href="#contact" className="text-lime-400 font-bold uppercase tracking-widest border-b-2 border-lime-400 pb-1 hover:text-white hover:border-white transition-colors">
          View All Trainers
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {TRAINERS.map((trainer) => (
          <div key={trainer.id} className="group flex flex-col items-center text-center">
            <div className="relative w-full aspect-[4/5] overflow-hidden rounded-3xl mb-6 shadow-2xl">
              <img
                src={trainer.image}
                alt={trainer.name}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 scale-100 group-hover:scale-105"
              />
              {/* Social Hover Overlay */}
              <div className="absolute inset-0 bg-zinc-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <a 
                  href={socialLink} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-lime-400 p-3 rounded-full text-zinc-950 hover:bg-white transition-colors cursor-pointer"
                >
                  <Instagram size={20} />
                </a>
                <a 
                  href={socialLink} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-lime-400 p-3 rounded-full text-zinc-950 hover:bg-white transition-colors cursor-pointer"
                >
                  <Twitter size={20} />
                </a>
                <a 
                  href={socialLink} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-lime-400 p-3 rounded-full text-zinc-950 hover:bg-white transition-colors cursor-pointer"
                >
                  <Facebook size={20} />
                </a>
              </div>
            </div>
            <h3 className="font-display text-2xl font-bold uppercase italic text-lime-400 mb-1">
              {trainer.name}
            </h3>
            <p className="text-zinc-500 font-bold uppercase text-xs tracking-[0.2em] mb-4">
              {trainer.specialty}
            </p>
            <p className="text-zinc-400 text-sm max-w-[280px]">
              {trainer.bio}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Trainers;
import React from 'react';
import { Dumbbell, Instagram, Facebook, Twitter, Youtube, Send } from 'lucide-react';
import { GYM_DETAILS } from '../constants';

const Footer: React.FC = () => {
  const socialLink = "https://www.instagram.com/porkys_kendall?igsh=dWxkZ3pzMTVubmc4";

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-6 group">
              <Dumbbell className="w-8 h-8 text-lime-400 group-hover:rotate-12 transition-transform" />
              <span className="font-display text-2xl font-bold tracking-tighter uppercase italic">
                Porky's <span className="text-lime-400">Hardcore</span>
              </span>
            </a>
            <p className="text-zinc-500 text-sm leading-relaxed mb-8">
              {GYM_DETAILS.description}
            </p>
            <div className="flex gap-4">
              <a 
                href={socialLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-zinc-900 p-3 rounded-full text-zinc-400 hover:text-lime-400 hover:bg-zinc-800 transition-all cursor-pointer"
              >
                <Instagram size={18} />
              </a>
              <a 
                href={socialLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-zinc-900 p-3 rounded-full text-zinc-400 hover:text-lime-400 hover:bg-zinc-800 transition-all cursor-pointer"
              >
                <Facebook size={18} />
              </a>
              <a 
                href={socialLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-zinc-900 p-3 rounded-full text-zinc-400 hover:text-lime-400 hover:bg-zinc-800 transition-all cursor-pointer"
              >
                <Twitter size={18} />
              </a>
              <a 
                href={socialLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-zinc-900 p-3 rounded-full text-zinc-400 hover:text-lime-400 hover:bg-zinc-800 transition-all cursor-pointer"
              >
                <Youtube size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold uppercase italic text-white mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#home" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Home</a></li>
              <li><a href="#programs" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Programs</a></li>
              <li><a href="#trainers" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Our Trainers</a></li>
              <li><a href="#pricing" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Pricing Plans</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold uppercase italic text-white mb-6">Explore</h4>
            <ul className="space-y-4">
              <li><a href="#schedule" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Schedule</a></li>
              <li><a href="#gallery" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Gallery</a></li>
              <li><a href="#testimonials" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Testimonials</a></li>
              <li><a href="#contact" className="text-zinc-500 hover:text-lime-400 transition-colors text-sm font-semibold uppercase tracking-wider">Book Trial</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold uppercase italic text-white mb-6">Newsletter</h4>
            <p className="text-zinc-500 text-sm mb-6">Get hardcore fitness tips and exclusive gym updates directly in your inbox.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Email address"
                className="bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 flex-grow text-sm focus:outline-none focus:border-lime-400 transition-colors"
              />
              <button className="bg-lime-400 text-zinc-950 px-4 py-3 rounded-lg font-bold">
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-zinc-900 pt-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-zinc-600 text-xs font-bold uppercase tracking-widest">
            © {new Date().getFullYear()} Porky's Hardcore Fitness. All Rights Reserved.
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-zinc-600 hover:text-zinc-400 text-xs font-bold uppercase tracking-widest transition-colors">Privacy Policy</a>
            <a href="#" className="text-zinc-600 hover:text-zinc-400 text-xs font-bold uppercase tracking-widest transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
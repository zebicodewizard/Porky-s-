
import React from 'react';
import { PROGRAMS } from '../constants';

const Programs: React.FC = () => {
  return (
    <div className="container mx-auto px-4 md:px-6">
      <div className="text-center mb-16">
        <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4 italic">
          Forge Your <span className="text-lime-400 underline decoration-2 underline-offset-8">Body</span>
        </h2>
        <p className="text-zinc-400 max-w-2xl mx-auto">
          From competitive bodybuilding to general fitness, we provide the specialized environment you need to excel.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {PROGRAMS.map((program) => (
          <div
            key={program.id}
            className="group relative h-96 overflow-hidden rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-lime-400/50 transition-all duration-500"
          >
            {/* Background Image */}
            <div className="absolute inset-0 z-0">
              <img
                src={program.image}
                alt={program.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:opacity-40 opacity-20"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 to-transparent"></div>
            </div>

            {/* Content */}
            <div className="relative z-10 h-full p-8 flex flex-col justify-end">
              <div className="bg-lime-400 w-12 h-12 rounded-xl flex items-center justify-center text-zinc-950 mb-6 transform group-hover:-translate-y-2 transition-transform duration-300">
                {program.icon}
              </div>
              <h3 className="font-display text-2xl font-bold uppercase italic mb-3 group-hover:text-lime-400 transition-colors">
                {program.title}
              </h3>
              <p className="text-zinc-400 text-sm leading-relaxed mb-4 line-clamp-2">
                {program.description}
              </p>
              <button className="text-xs font-bold uppercase tracking-[0.2em] text-lime-400 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                Learn More <span className="text-lg">→</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Programs;

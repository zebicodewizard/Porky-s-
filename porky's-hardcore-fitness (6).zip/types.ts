// Fix: Added React import to resolve the "Cannot find namespace 'React'" error for React.ReactNode on line 7
import React from 'react';

export interface Program {
  id: string;
  title: string;
  description: string;
  image: string;
  icon: React.ReactNode;
}

export interface Trainer {
  id: string;
  name: string;
  specialty: string;
  image: string;
  bio: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  features: string[];
  isFeatured?: boolean;
}

export interface Testimonial {
  id: string;
  author: string;
  text: string;
  rating: number;
}
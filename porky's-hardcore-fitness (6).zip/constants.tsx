
import React from 'react';
import { Dumbbell, Users, Utensils, Zap, Trophy, HeartPulse } from 'lucide-react';
import { Program, Trainer, PricingPlan, Testimonial } from './types';

export const GYM_DETAILS = {
  name: "Porky's Hardcore Fitness",
  location: "NELSAY PLAZA",
  address: "15682 SW 72nd St, Miami, FL 33193, United States",
  phone: "+1 305-383-0018",
  hours: "Open · Closes 9pm",
  description: "Porky's hardcore fitness is a Gym where serious people that committed come to train. We are not your big corporate gym; it's a total different atmosphere where people help each other and motivate one another."
};

export const PROGRAMS: Program[] = [
  {
    id: '1',
    title: 'Hardcore Bodybuilding',
    description: 'High-intensity resistance training designed for maximum muscle growth and definition.',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1470',
    icon: <Dumbbell className="w-8 h-8" />
  },
  {
    id: '2',
    title: 'Personal Coaching',
    description: 'One-on-one sessions tailored to your specific goals, from weight loss to competition prep.',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=1470',
    icon: <Users className="w-8 h-8" />
  },
  {
    id: '3',
    title: 'Nutrition Strategy',
    description: 'Expert advice and supplement guidance from our in-house nutrition store.',
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=1470',
    icon: <Utensils className="w-8 h-8" />
  },
  {
    id: '4',
    title: 'Functional Power',
    description: 'Build real-world strength and explosive energy with our functional fitness programs.',
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1470',
    icon: <Zap className="w-8 h-8" />
  }
];

export const TRAINERS: Trainer[] = [
  {
    id: 't1',
    name: 'Marco "Porky" Silva',
    specialty: 'Master Bodybuilding Coach',
    image: 'https://lh3.googleusercontent.com/gps-cs-s/AHVAweoQ-sQXNauMcfpPfHjR09ZltCqfiP8OWknpwvjEU-fkrUhS1rFyS0Lgp4yPzrBEyXZ3JqNLknKxuhxX40bPy2EnZy7SBwx1k7FuhkE9j_XR4OyQ4Q9gpIpzlURAL2W_VGvAEXBScQ=w243-h244-n-k-no-nu',
    bio: 'With over 20 years of experience, Marco focuses on results-driven hardcore training.'
  },
  {
    id: 't2',
    name: 'Sarah Jenkins',
    specialty: 'Nutrition & Competition Prep',
    image: 'https://lh3.googleusercontent.com/gps-cs-s/AHVAwerocHIkGlW5lFItIS399MBQmZRSrTAHz34FYrqDhSfHN27NMZIM1NaLCAv0dicO9ITMCpdv3A172I5Gv_Q83nNy6CtiW3RJtYOOiAY7UDfM6i9ukVGnqGioMLzx-vTe0ynVXW4N=s680-w680-h510-rw',
    bio: 'Sarah helps athletes fine-tune their diet for peak stage performance.'
  },
  {
    id: 't3',
    name: 'David Chen',
    specialty: 'Strength & Conditioning',
    image: 'https://c.superprof.com/i/m/17345569/600/20221123152814/17345569.webp',
    bio: 'Specialist in powerlifting and explosive athletic movements.'
  }
];

export const PRICING: PricingPlan[] = [
  {
    id: 'p1',
    name: 'Basic Grinder',
    price: '$45',
    features: ['Full Facility Access', 'Modern Equipment', 'Free Locker Room']
  },
  {
    id: 'p2',
    name: 'Pro Warrior',
    price: '$75',
    features: ['Everything in Basic', 'Unlimited Classes', '1 Personal Training Session/mo', 'Nutrition Store Discounts'],
    isFeatured: true
  },
  {
    id: 'p3',
    name: 'Elite Titan',
    price: '$120',
    features: ['Everything in Pro', 'Weekly Coaching', 'Personalized Meal Plans', 'Free Post-Workout Shakes']
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'res1',
    author: 'Sergio Sanchez',
    text: 'Nice environment to workout, friendly staff and good customer service!!!',
    rating: 5
  },
  {
    id: 'res2',
    author: 'Kimberly Velar',
    text: 'Great atmosphere and amazing people, a must check out for your work out needs.',
    rating: 5
  },
  {
    id: 'res3',
    author: 'Luis Miguel Navarro',
    text: 'Best gym in Miami, super clean, great prices, excellent costumer service.',
    rating: 5
  }
];

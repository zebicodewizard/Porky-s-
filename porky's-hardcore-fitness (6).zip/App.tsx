import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Programs from './components/Programs';
import Trainers from './components/Trainers';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Gallery from './components/Gallery';
import Schedule from './components/Schedule';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import Profile from './components/Profile';
import AINutritionAssistant from './components/AINutritionAssistant';
import { supabase } from './supabaseClient';
import { User } from '@supabase/supabase-js';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [view, setView] = useState<'landing' | 'profile'>('landing');

  useEffect(() => {
    // Check current session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    // Listen for changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (!session) setView('landing');
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col">
      <Header 
        user={user} 
        onAuthClick={() => setIsAuthModalOpen(true)} 
        onProfileClick={() => setView('profile')}
        onHomeClick={() => setView('landing')}
      />
      
      <main className="flex-grow">
        {view === 'landing' ? (
          <>
            <section id="home">
              <Hero />
            </section>
            <section id="programs" className="py-20 bg-zinc-950">
              <Programs />
            </section>
            <section id="trainers" className="py-20 bg-zinc-900/50">
              <Trainers />
            </section>
            <section id="pricing" className="py-20 bg-zinc-950">
              <Pricing />
            </section>
            <section id="schedule" className="py-20 bg-zinc-900/50">
              <Schedule user={user} onAuthRequired={() => setIsAuthModalOpen(true)} />
            </section>
            <section id="gallery" className="py-20 bg-zinc-950">
              <Gallery />
            </section>
            <section id="testimonials" className="py-20 bg-zinc-900/50">
              <Testimonials />
            </section>
            <section id="contact" className="py-20 bg-zinc-950">
              <Contact user={user} />
            </section>
          </>
        ) : (
          <div className="pt-24 pb-20">
            <Profile user={user} />
          </div>
        )}
      </main>

      <Footer />
      <AINutritionAssistant />

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
      />
    </div>
  );
};

export default App;
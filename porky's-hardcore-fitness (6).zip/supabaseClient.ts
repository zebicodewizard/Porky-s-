import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://klttxomxczeybwlyiqkm.supabase.co';
const supabaseKey = 'sb_publishable_zAmMPJgM3BMTW58hPsVogw_Pd8HC-DD';

export const supabase = createClient(supabaseUrl, supabaseKey);